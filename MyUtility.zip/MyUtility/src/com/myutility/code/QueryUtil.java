package com.myutility.code;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class QueryUtil {
	public static final String HEADER="header";
	public static final String FOOTER="footer";
	public static final String ROW_START="rowStart";
	public static final String ROW_START_HEADER="rowStartHeader";
	public static final String ROW_START_BG_COLOR="rowStartBgColor";
	public static final String ROW_END="rowEnd";
	public static final String COLUMN_START="columnStart";
	public static final String COLUMN_END="columnEnd";
	public static final String COLUMN_CENTRE_START="centreStart";
	public static final String COLUMN_CENTRE_END="centreEnd";
	public static final String QUERY_OUTPUT="output.html";
	
	
	public static void main(String ...strings){
		String query="select 'EN|SN|WH' AS entityIdCode ,B.PHCO AS entityName ,'92' AS idCodeQualifier ,'1231312' AS idCode ,E.WR_SADDR AS addressInfo ,case WHEN upper(B.RTYPE) ='' THEN '32' WHEN upper(B.RTYPE) ='R' THEN '76' Else '' END AS quantityQualifier ,'1' AS quantity ,'1' AS lineItemNumber ,case WHEN A.WR_SKU_N1 <>'' THEN 'SK' Else '' END AS staplesSKUQualifier ,A.WR_SKU_N1 AS staplesSKU ,case WHEN A.WR_VNDPRTN <>'' THEN 'VP' Else '' END AS vendorSKUQualifier ,A.WR_VNDPRTN AS  vendorSKU ,case WHEN D.IUPC >0  THEN 'UP' Else '' END AS upcQualifier ,D.IUPC AS upcNumber ,case WHEN A.WR_SKUNM1 <>'' THEN 'F' Else '' END AS itemDescriptionType ,A.WR_SKUNM1  AS freeFormDescription ,case WHEN B.serial# <>'' THEN 'SE' Else '' END AS productSerialNumberQualifier ,B.serial# AS productSerialNumber ,'PO' AS purchaseOrderNumberQualifier ,'purchaseOrderNumber'AS purchaseOrderNumber ,'IK' AS invoiceNumberQualifier ,'invoiceNumber' AS invoiceNumber ,case WHEN A.WR_DATTIME <>'' THEN '321' Else '' END AS purchaseDateQualifier ,VARCHAR_FORMAT(A.WR_DATTIME, 'YYYYMMDD') AS purchaseDate ,case WHEN A.WR_DATTIME <>'' THEN '003' Else '' END AS invoiceDateQualifier ,VARCHAR_FORMAT(A.WR_DATTIME, 'YYYYMMDD') AS invoiceDate from WR_DETL A, WR_ADDR E , WR_HEDR F , SC7455TRN B left outer join INVUPC D on (B.CDBRCD=CAST(D.INUMBR as VARCHAR(20)) AND D.IUACTV='Y') where A.WR_SKU_N1=B.CDBRCD AND A.WR_REFNO=E.WR_REFNO AND A.WR_REFNO=F.WR_REFNO AND F.WR_DIV= '051' AND B.PHPKTN <> ''  AND A.WR_VEND='26861'  AND date(B.SCNDAT) > '2016-05-01' ";
		runSelectQuery(query,"sunbeam","mmbaslib");
	}
	
	
	
	
	
	public static void runSelectQuery(final String Query,final String server,final String library){
		Connection con=ConnectionUtil.getConnection(server,library);
		ResultSet rs=null;
		StringBuffer buffer=new StringBuffer(PropertiesUtil.getProperty(HEADER));
		PreparedStatement stmt=null;
		int bgColorCounter=1;
		try {
			stmt=con.prepareStatement(Query);
			rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			buffer.append(PropertiesUtil.getProperty(HEADER));
			// The column count starts from 1
			buffer.append(PropertiesUtil.getProperty(ROW_START_HEADER));
			for (int i = 1; i <= columnCount; i++ ) {
				buffer.append(PropertiesUtil.getProperty(COLUMN_START))
				.append(PropertiesUtil.getProperty(COLUMN_CENTRE_START))
				.append(rsmd.getColumnName(i))
				.append(PropertiesUtil.getProperty(COLUMN_CENTRE_END)).
				append(PropertiesUtil.getProperty(COLUMN_END));
			}
			buffer.append(PropertiesUtil.getProperty(ROW_END));
			while (rs.next()) {
				if(bgColorCounter%2==0){
					buffer.append(PropertiesUtil.getProperty(ROW_START_BG_COLOR));
				}else{
					buffer.append(PropertiesUtil.getProperty(ROW_START));
				}
				for (int i = 1; i <= columnCount; i++ ) {
					buffer.append(PropertiesUtil.getProperty(COLUMN_START))
					.append(rs.getString(i)).
					append(PropertiesUtil.getProperty(COLUMN_END));
				}
				buffer.append(PropertiesUtil.getProperty(ROW_END));
				bgColorCounter++;
			}
			buffer.append(PropertiesUtil.getProperty(FOOTER));
			FileUtil.writeToFile(buffer.toString(), QUERY_OUTPUT);
		} catch (SQLException e) {
			System.out.println("Error while executing Query...");
			e.printStackTrace();
		}finally {
			ConnectionUtil.closeResultSet(rs);
			ConnectionUtil.closeStatement(stmt);
			ConnectionUtil.closeConnection(con);
		}
	}

}
