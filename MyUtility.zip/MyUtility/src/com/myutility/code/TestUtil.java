package com.myutility.code;

public class TestUtil {

	public static void main(int i,String[] args) {
		System.out.println("roy");
		
	}
	public static void main(String[] args) {
		System.out.println("Abhijit");
		
	}
	
}
